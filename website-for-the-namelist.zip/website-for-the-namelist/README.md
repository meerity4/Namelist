# Website for the Namelist

A Pen created on CodePen.

Original URL: [https://codepen.io/Meerit-Yakob/pen/raVvoyV](https://codepen.io/Meerit-Yakob/pen/raVvoyV).

